# 风险分析 · 数据价值分析工作台

从 `nextjs-version` 拆出的独立单页工程，仅保留「风险分析 / 数据价值分析工作台」
（根路径 `/`），登录、其他工作台、任务、系统管理等均已移除。
页面铺满视口，左侧一二级菜单已移除。

## 运行

```bash
pnpm install
pnpm dev        # http://localhost:8021
```

生产构建：

```bash
pnpm build
pnpm start      # http://localhost:8021
```

## 结构

| 路径 | 说明 |
| --- | --- |
| `app/layout.tsx` | 根布局，挂载 `PactorApp`（跨路由常驻） |
| `app/api/sitemap/route.ts` | 下发内联了布局 / 页面 DSL 的 sitemap |
| `app/api/risk-analysis/data-value/route.ts` | 页面数据（KPI / 分布 / 散点 / PSI） |
| `app/api/risk-analysis/feature-source-summary/route.ts` | 特征来源汇总表格数据（服务端分页） |
| `src/server/yaml/` | sitemap 与页面 YAML DSL |
| `src/shared/data-value.ts` | 页面演示数据与按日期区间的派生逻辑 |
| `src/pactor/components/` | 外壳与页面样式 |

页面由 Pactor server-driven UI 渲染：`src/server/yaml/risk-analysis/risk-data-value.page.yaml`
与源工程保持一致，仅移除了依赖宿主应用的 `risk.enterPage` 生命周期。